import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final employeeProvider = EmployeeProvider();
  await employeeProvider.fetchAndStoreEmployees(); // Fetch and store employees
  runApp(const MyApp());
}


class Address {
  final String street;
  final String suite;
  final String city;
  final String zipcode;

  Address({
    required this.street,
    required this.suite,
    required this.city,
    required this.zipcode,
  });

  factory Address.fromJson(Map<String, dynamic> json) {
    return Address(
      street: json['street'],
      suite: json['suite'],
      city: json['city'],
      zipcode: json['zipcode'],
    );
  }
}

class Company {
  final String name;
  final String catchPhrase;
  final String bs;

  Company({
    required this.name,
    required this.catchPhrase,
    required this.bs,
  });

  factory Company.fromJson(Map<String, dynamic> json) {
    return Company(
      name: json['name'],
      catchPhrase: json['catchPhrase'],
      bs: json['bs'],
    );
  }
}

class Employee {
  final String id;
  final String name;
  final String username;
  final String email;
  final String profileImage;
  final Address address;
  final String phone;
  final String website;
  final Company? company;

  Employee({
    required this.id,
    required this.name,
    required this.username,
    required this.email,
    required this.profileImage,
    required this.address,
    required this.phone,
    required this.website,
    this.company,
  });

  factory Employee.fromJson(Map<String, dynamic> json) {
    return Employee(
      id: json['id'].toString(),
      name: json['name'],
      username: json['username'],
      email: json['email'],
      profileImage: json['profile_image'] ?? "",
      address: Address.fromJson(json['address']),
      phone: json['phone'] ?? "",
      website: json['website'] ?? "",
      company: json['company'] != null ? Company.fromJson(json['company']) : null,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'username': username,
      'email': email,
      'profileImage': profileImage,
      'street': address.street,
      'suite': address.suite,
      'city': address.city,
      'zipcode': address.zipcode,
      'phone': phone,
      'website': website,
      'companyName': company?.name,
      'catchPhrase': company?.catchPhrase,
      'bs': company?.bs,
    };
  }
}

class EmployeeProvider {
  static final EmployeeProvider _instance = EmployeeProvider._privateConstructor();
  EmployeeProvider._privateConstructor();

  factory EmployeeProvider() {
    return _instance;
  }

  Future<void> fetchAndStoreEmployees() async {
    final response = await http.get(Uri.parse('http://www.mocky.io/v2/5d565297300000680030a986'));
    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      final employees = (data as List).map((json) => Employee.fromJson(json)).toList();
      await _insertEmployees(employees);
    } else {
      throw Exception('Failed to fetch employees');
    }
  }

  Future<void> _insertEmployees(List<Employee> employees) async {
  final db = await openDatabase(
    join(await getDatabasesPath(), 'employee_database.db'),
    onCreate: (db, version) {
      return db.execute(
        '''
        CREATE TABLE employees(
          id TEXT PRIMARY KEY, 
          name TEXT, 
          username TEXT, 
          email TEXT, 
          profileImage TEXT, 
          street TEXT, 
          suite TEXT, 
          city TEXT, 
          zipcode TEXT, 
          phone TEXT, 
          website TEXT, 
          companyName TEXT, 
          catchPhrase TEXT, 
          bs TEXT
        )
        ''',
      );
    },
    version: 1,
  );

  await db.transaction((txn) async {
    for (var employee in employees) {
      await txn.insert(
        'employees',
        employee.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    }
  });
}

  Future<List<Employee>> getEmployeesFromDatabase() async {
  final db = await openDatabase(join(await getDatabasesPath(), 'employee_database.db'));
  final List<Map<String, dynamic>> maps = await db.query('employees');

  return List.generate(maps.length, (i) {
    final map = maps[i];
    return Employee(
      id: map['id'] as String,
      name: map['name'] as String,
      username: map['username'] as String,
      email: map['email'] as String,
      profileImage: map['profileImage'] as String,
      address: Address(
        street: map['street'] as String,
        suite: map['suite'] as String,
        city: map['city'] as String,
        zipcode: map['zipcode'] as String,
      ),
      phone: map['phone'] as String? ?? "",
      website: map['website'] as String? ?? "",
      company: Company(
      name: map['companyName'] as String? ?? "", // Use an empty string as default if null
      catchPhrase: map['catchPhrase'] as String? ?? "",
      bs: map['bs'] as String? ?? "",
    ),
    );
  });
}

}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Employee Directory',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const EmployeeListScreen(),
    );
  }
}

class EmployeeListScreen extends StatefulWidget {
  const EmployeeListScreen({super.key});

  @override
  _EmployeeListScreenState createState() => _EmployeeListScreenState();
}

class _EmployeeListScreenState extends State<EmployeeListScreen> {
  List<Employee> _allEmployees = [];
  List<Employee> _filteredEmployees = [];

  @override
  void initState() {
    super.initState();
    _fetchEmployeesFromDatabase().then((employees) {
      setState(() {
        _allEmployees = employees;
        _filteredEmployees = employees;
      });
    });
  }

  Future<List<Employee>> _fetchEmployeesFromDatabase() async {
    final employeeProvider = EmployeeProvider();
    return employeeProvider.getEmployeesFromDatabase();
  }

  void _filterEmployees(String query) {
    setState(() {
      _filteredEmployees = _allEmployees.where((employee) {
        return employee.name.toLowerCase().contains(query.toLowerCase()) ||
            employee.email.toLowerCase().contains(query.toLowerCase());
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Employee List')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              onChanged: _filterEmployees,
              decoration: const InputDecoration(
                labelText: 'Search by name or email',
                prefixIcon: Icon(Icons.search),
              ),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: _filteredEmployees.length,
              itemBuilder: (context, index) {
                final employee = _filteredEmployees[index];
                return ListTile(
                  leading: CircleAvatar(
                    backgroundImage: NetworkImage(employee.profileImage),
                  ),
                  title: Text(employee.name),
                  subtitle: Text(employee.company?.name ?? ""),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => EmployeeDetailsScreen(employee: employee),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class EmployeeDetailsScreen extends StatelessWidget {
  final Employee employee;

  const EmployeeDetailsScreen({super.key, required this.employee});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Employee Details')),
      body: Column(
        children: [
          CircleAvatar(
            backgroundImage: NetworkImage(employee.profileImage),
          ),
          Text(employee.name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          Text(employee.username),
          Text(employee.email),
          Text('Address: ${employee.address.street}, ${employee.address.suite}, ${employee.address.city}, ${employee.address.zipcode}'),
          Text('Phone: ${employee.phone.isNotEmpty ? employee.phone : "N/A"}'),
          Text('Website: ${employee.website.isNotEmpty ? employee.website : "N/A"}'),
          if (employee.company != null) ...[
            const Text('Company Details:'),
            Text('Company Name: ${employee.company!.name}'),
            Text('Catch Phrase: ${employee.company!.catchPhrase}'),
            Text('Business Services: ${employee.company!.bs}'),
          ],
        ],
      ),
    );
  }
}
